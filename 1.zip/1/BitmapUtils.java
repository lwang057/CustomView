/*
    ShengDao Android Client, BitmapUtils
    Copyright (c) 2014 ShengDao Tech Company Limited
 */

package com.yonyou.zgcbank.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.View;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * [A brief description]
 *
 * @author huxinwu
 * @version 1.0
 * @date 2014-3-18
 **/
public class BitmapUtils {

    /**
     * 从资源文件中获取图片资源转化成bitmap
     *
     * @param context
     * @param resId   图片id
     * @return
     */
    public static Bitmap getResBitmap(@NonNull Context context, int resId) {
        Resources res = context.getResources();
        return BitmapFactory.decodeResource(res, resId);
    }

    /**
     * 图片缩放
     *
     * @param photo
     * @param newHeight
     * @param context
     * @return
     */
    @NonNull
    public static Bitmap scaleBitmap(@NonNull Bitmap photo, int newHeight, @NonNull Context context) {
        final float densityMultiplier = context.getResources().getDisplayMetrics().density;
        int h = (int) (newHeight * densityMultiplier);
        int w = (int) (h * photo.getWidth() / ((double) photo.getHeight()));
        photo = Bitmap.createScaledBitmap(photo, w, h, true);
        return photo;
    }

    /**
     * byte[]转Bitmap
     *
     * @param bytes
     * @return
     */
    public static Bitmap Bytes2Bimap(@NonNull byte[] bytes) {
        if (bytes.length != 0) {
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        }
        return null;
    }

    /**
     * Bitmap转byte[]
     *
     * @param bitmap
     * @return
     */
    public static byte[] Bitmap2Bytes(@NonNull Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.PNG, 100, baos);
        return baos.toByteArray();
    }

    /**
     * 字符串转换成Bitmap类型
     *
     * @return
     */
    @Nullable
    public static Bitmap stringtoBitmap(String imgBase64Str) {
        Bitmap bitmap = null;
        byte[] bitmapArray;
        try {
            bitmapArray = Base64.decode(imgBase64Str, Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    /**
     * 将Bitmap转换成字符串
     *
     * @param bitmap
     * @return
     */
    @Nullable
    public static String bitmaptoString(@NonNull Bitmap bitmap) {
        String result = null;
        try {
            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            bitmap.compress(CompressFormat.PNG, 100, bStream);
            byte[] bytes = bStream.toByteArray();
            result = Base64.encodeToString(bytes, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据图片路径读取经过压缩处理过的图片
     * 如果图片很大，不能全部加在到内存中处理，要是全部加载到内存中会内存溢出
     *
     * @param filePath  图片路径
     * @param reqWidth  要求的宽
     * @param reqHeight 要求的高
     * @return
     */
    public static Bitmap decodeBitmapPath(String filePath, int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(filePath, options);
    }

    /**
     * 读取资源文件中经过压缩处理过的图片
     * 使用方法：decodeBitmapResource(getResources(), R.id.myimage, 100, 100));
     *
     * @param res       Resources对象
     * @param resId     资源id
     * @param reqWidth  要求的宽
     * @param reqHeight 要求的高
     * @return
     */
    public static Bitmap decodeBitmapResource(Resources res, int resId, int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }

    public static Bitmap compressImage(@NonNull Bitmap image) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, baos);//质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        int options = 100;
        while (baos.toByteArray().length / 1024 > 10) {    //循环判断如果压缩后图片是否大于100kb,大于继续压缩
            baos.reset();//重置baos即清空baos
            options -= 50;//每次都减少10
            image.compress(Bitmap.CompressFormat.JPEG, options, baos);//这里压缩options%，把压缩后的数据存放到baos中
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());//把压缩后的数据baos存放到ByteArrayInputStream中
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);//把ByteArrayInputStream数据生成图片
        return bitmap;
    }

    public static Bitmap compressSimple(@NonNull Bitmap mCardImage1) {
        Bitmap bt = Bitmap.createBitmap(mCardImage1, mCardImage1.getWidth() / 8 * 5, mCardImage1.getHeight() / 7,
                mCardImage1
                        .getWidth() / 3, mCardImage1.getHeight() / 5 * 3);
        return bt;
    }

    /**
     * 目前使用该方法---------------*********************
     *
     * @param bmp
     * @return
     */
    public static Bitmap compress(@NonNull Bitmap bmp) {
        // 首先进行一次大范围的压缩
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, output);
        float zoom = (float) Math.sqrt(32 * 1024 / (float) output.toByteArray().length); //获取缩放比例
        // 设置矩阵数据
        Matrix matrix = new Matrix();
        matrix.setScale(zoom, zoom);
        // 根据矩阵数据进行新bitmap的创建
        Bitmap resultBitmap = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), matrix, true);
        output.reset();
        resultBitmap.compress(CompressFormat.JPEG, 100, output);
        // 如果进行了上面的压缩后，依旧大于32K，就进行小范围的微调压缩
        while (output.toByteArray().length > 100 * 1024) {
            matrix.setScale(0.9f, 0.9f);//每次缩小 1/10
            resultBitmap = Bitmap.createBitmap(resultBitmap, 0, 0, resultBitmap.getWidth(), resultBitmap.getHeight(),
                    matrix, true);
            output.reset();
            resultBitmap.compress(Bitmap.CompressFormat.JPEG, 100, output);
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(output.toByteArray());//把压缩后的数据baos存放到ByteArrayInputStream中
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);//把ByteArrayInputStream数据生成图片
        return bitmap;
    }

    public static Bitmap comp(@NonNull Bitmap image) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        if (baos.toByteArray().length / 1024 > 1024) {//判断如果图片大于1M,进行压缩避免在生成图片（BitmapFactory.decodeStream）时溢出
            baos.reset();//重置baos即清空baos
            image.compress(CompressFormat.JPEG, 60, baos);//这里压缩50%，把压缩后的数据存放到baos中
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());
        BitmapFactory.Options newOpts = new BitmapFactory.Options();
        //开始读入图片，此时把options.inJustDecodeBounds 设回true了
        newOpts.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, newOpts);
        newOpts.inJustDecodeBounds = false;
        int w = newOpts.outWidth;
        int h = newOpts.outHeight;
        //现在主流手机比较多是800*480分辨率，所以高和宽我们设置为
        float hh = 165f;//这里设置高度为800f
        float ww = 280f;//这里设置宽度为480f
        //缩放比。由于是固定比例缩放，只用高或者宽其中一个数据进行计算即可
        int be = 1;//be=1表示不缩放
        if (w > h && w > ww) {//如果宽度大的话根据宽度固定大小缩放
            be = (int) (newOpts.outWidth / ww);
        } else if (w < h && h > hh) {//如果高度高的话根据宽度固定大小缩放
            be = (int) (newOpts.outHeight / hh);
        }
        if (be <= 0) {
            be = 1;
        }
        newOpts.inSampleSize = be;//设置缩放比例
        //重新读入图片，注意此时已经把options.inJustDecodeBounds 设回false了
        isBm = new ByteArrayInputStream(baos.toByteArray());
        bitmap = BitmapFactory.decodeStream(isBm, null, newOpts);
        return compressImage(bitmap);//压缩好比例大小后再进行质量压缩
    }

    /**
     * 计算压缩的值，谷歌官方方法
     *
     * @param options   BitmapFactory.Options
     * @param reqWidth  要求的宽
     * @param reqHeight 要求的高
     * @return
     */
    private static int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {

        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and  keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    /**
     * 把图片变成圆角
     *
     * @param bitmap 需要修改的图片
     * @param pixels 圆角的弧度
     * @return 圆角图片
     */
    public static Bitmap toRoundCorner(@NonNull Bitmap bitmap, int pixels) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = pixels;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }

    //----------------------------------------------------------------
    // 对图像数据源采样
    public static Bitmap getThumbnailBitmap(@NonNull byte[] data, int sampleSize) {
        // 第一次采样：目的是只获取图片的宽度和高度，并不希望获得图片像素点的全部数据
        BitmapFactory.Options options = new BitmapFactory.Options();
        // 第一次采样，只采图片的边界
        options.inJustDecodeBounds = true;
        // 开始执行第一次采样
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        // 设置压缩比例
        options.inSampleSize = sampleSize;
        // 图片进行第二次采样，既要采集图片的边界信息，又需要采集图片像素点的数据
        options.inJustDecodeBounds = false;
        Bitmap thumbnailBitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
        return thumbnailBitmap;
    }

    // 对Bitmap对象采样，压缩倍数只有为2的n次方倍数时有效
    public static Bitmap getThumbnailBitmap(@NonNull Bitmap bitmap, int sampleSize) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        BitmapFactory.Options options = new BitmapFactory.Options();
        // 2.解码边缘
        options.inJustDecodeBounds = true;
        // 3进行图片解码
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        options.inSampleSize = sampleSize;
        // 4.锁住边缘
        options.inJustDecodeBounds = false;
        // 5.通过参数获得新的位图
        Bitmap thumbnailBitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
        return thumbnailBitmap;
    }

    //图片二次采样---压缩
    //bitmap:原图
    //sampleSize:压缩比例
    public static Bitmap getThumbnailBitmaptt(@NonNull Bitmap bitmap, int sampleSize) {
        //输出流
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        /**
         * 参数1:图片格式,2:图片质量:0-100,3:输出流
         */
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        //创建一个图像的配置对象
        BitmapFactory.Options options = new BitmapFactory.Options();
        //解码边缘
        options.inJustDecodeBounds = true;
        //第一次采样,只是获取原图的宽高
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        //
        options.inSampleSize = sampleSize;
        //第二次采样,在已知宽高和压缩比例的情况下,获取缩略图
        options.inJustDecodeBounds = false;
        Bitmap thumbnailBitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
        return thumbnailBitmap;
    }

    /**
     * 屏幕截屏方法 获取当前屏幕bitmap
     *
     * @param activity
     * @return
     */
    public Bitmap printscreen(@NonNull Activity activity) {
        View view = activity.getWindow().getDecorView();
        int width = CommonUtils.getScreenHeight(activity);
        int height = CommonUtils.getScreenHeight(activity);
        view.layout(0, 0, width, height);
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        return bitmap;
    }

    /**
     * 将Bitmap转换成InputStream
     *
     * @param bm
     * @return
     */
    @NonNull
    public InputStream Bitmap2InputStream(@NonNull Bitmap bm) {
        return Bitmap2InputStream(bm, 100);
    }

    /**
     * 将Bitmap转换成InputStream
     *
     * @param bm
     * @param quality
     * @return
     */
    @NonNull
    private InputStream Bitmap2InputStream(@NonNull Bitmap bm, int quality) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(CompressFormat.PNG, quality, baos);
        InputStream is = new ByteArrayInputStream(baos.toByteArray());
        return is;
    }

    /**
     * 将InputStream转换成Bitmap
     *
     * @param is
     * @return
     */
    public Bitmap InputStream2Bitmap(InputStream is) {
        return BitmapFactory.decodeStream(is);
    }

    /**
     * Bitmap转换成Drawable
     *
     * @param bitmap
     * @return
     */
    @NonNull
    @SuppressWarnings("deprecation")
    public Drawable bitmap2Drawable(Bitmap bitmap) {
        BitmapDrawable bd = new BitmapDrawable(bitmap);
        Drawable drawable = bd;
        return drawable;
    }

    /*************************************压缩图片start*******************************/
    /**
     * 压缩图片大小(人脸识别，身份证)
     */
    public static Bitmap compressImage2(@NonNull Bitmap image) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, baos);// 质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        int options = 100;
        LogUtils.e("bitmap+"+baos.toByteArray().length);
        while (baos.toByteArray().length / 1024 > 60) { // 循环判断如果压缩后图片是否大于100kb,大于继续压缩
            baos.reset();// 重置baos即清空baos
            image.compress(Bitmap.CompressFormat.JPEG, options, baos);// 这里压缩options%，把压缩后的数据存放到baos中
            options -= 10;// 每次都减少10
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());// 把压缩后的数据baos存放到ByteArrayInputStream中
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);// 把ByteArrayInputStream数据生成图片
        return bitmap;
    }

    /**
     * 压缩图片大小（头像）
     */
    public static Bitmap compressImage2head(@NonNull Bitmap image) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, baos);// 质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        int options = 100;
        while (baos.toByteArray().length / 1024 > 25) { // 循环判断如果压缩后图片是否大于100kb,大于继续压缩
            baos.reset();// 重置baos即清空baos
            image.compress(Bitmap.CompressFormat.JPEG, options, baos);// 这里压缩options%，把压缩后的数据存放到baos中
            if (options > 10) {
                options -= 10;// 每次都减少10
            } else {
                break;
            }
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());// 把压缩后的数据baos存放到ByteArrayInputStream中
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);// 把ByteArrayInputStream数据生成图片
        return bitmap;
    }

    /*************************************压缩图片end*******************************/


    /**
     * Drawable转换成Bitmap
     *
     * @param drawable
     * @return
     */
    public Bitmap drawable2Bitmap(@NonNull Drawable drawable) {
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), drawable
                .getOpacity() != PixelFormat.OPAQUE ? Config.ARGB_8888 : Config.RGB_565);

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    // 对本地图片进行二次采样
    public Bitmap getThumbnailBitmap(String pathName, int sampleSize) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(pathName, options);
        options.inSampleSize = sampleSize;
        options.inJustDecodeBounds = false;
        Bitmap thumbnailBitmap = BitmapFactory.decodeFile(pathName, options);
        return thumbnailBitmap;
    }


    /*************************************压缩图片start*******************************/
    /**
     * 压缩图片大小(人脸识别，身份证)
     */
    public static byte[] compressImage4(@NonNull Bitmap image) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, baos);// 质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        int options = 100;
        while (baos.toByteArray().length / 1024 >=  100) { // 循环判断如果压缩后图片是否大于100kb,大于继续压缩
            baos.reset();// 重置baos即清空baos
            image.compress(Bitmap.CompressFormat.JPEG, options, baos);// 这里压缩options%，把压缩后的数据存放到baos中
            options -= 10;// 每次都减少10
            if (options < 10){
                break;
            }
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());// 把压缩后的数据baos存放到ByteArrayInputStream中
        //Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);// 把ByteArrayInputStream数据生成图片
        return baos.toByteArray();
    }


    /**
     * 将Bitmap转换成字符串
     *
     * @param bytes
     * @return
     */
    @Nullable
    public static String bitmaptoStrings(@NonNull byte[] bytes) {
        String result = null;
        try {
            result = Base64.encodeToString(bytes, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     *                     String uriString = uri.toString();
     *                     grantUriPermission(getPackageName(),uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
     *                     intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
     *                     intent.putExtra("uri",uriString);
     *                     intent.putExtra("scan_side",scan_side);
     *                     setResult(400,intent);
     *
     *
     *                     String uriString = data.getStringExtra("uri");
     *                 int scan_side = data.getIntExtra("scan_side", -1);
     *                 Uri uri = Uri.parse(uriString);
     *                 if (scan_side == 1) {
     *                     dealWithFront(uri,scan_side);
     *                 }
     *
     *
     *
     //处理选择照片正面
     private void dealWithFront(Uri uri, final int scan_side) {
     Glide.with(getActivity()).load(uri).into(mPorIv);
     mPorIvBackgroud.setBackgroundResource(R.mipmap.id_zhezhao);
     mPorIvBackgroud.setSelected(true);
     Luban.with(getActivity())
     .load(uri)
     .ignoreBy(100)
     .setTargetDir(getPath())
     .setFocusAlpha(false)
     .filter(new CompressionPredicate() {
    @Override
    public boolean apply(String path) {
    return !(TextUtils.isEmpty(path) || path.toLowerCase().endsWith(".gif"));
    }
    })
     .setRenameListener(new OnRenameListener() {
    @Override
    public String rename(String filePath) {
    try {
    MessageDigest md = MessageDigest.getInstance("MD5");
    md.update(filePath.getBytes());
    return new BigInteger(1, md.digest()).toString(32);
    } catch (NoSuchAlgorithmException e) {
    e.printStackTrace();
    }
    return "";
    }
    })
     .setCompressListener(new OnCompressListener() {
    @Override
    public void onStart() { }

    @Override
    public void onSuccess(File file) {
    LogUtils.e("path++++"+file.getAbsolutePath());
    //showResult(originPhotos, file);
    Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
    String cardImage = BitmapUtils.bitmaptoStrings(baos.toByteArray());
    callServiceGetCardInfo(cardImage, baos,scan_side);
    }

    @Override
    public void onError(Throwable e) { }
    }).launch();
     }
     private String getPath() {
     String path = Environment.getExternalStorageDirectory() + "/zgcbank/image/";
     if (Build.VERSION.SDK_INT >= 29){
     path = getActivity().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "/zgcbank/image/";
     }
     File file = new File(path);
     if (file.mkdirs()) {
     return path;
     }
     return path;
     }

     */

}
